import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const MyStack = () => {
  return (
    <View>
      <Text>MyStack</Text>
    </View>
  )
}

export default MyStack

const styles = StyleSheet.create({})